#!/bin/bash
echo "What directory do you want to add to the PATH."
read NEWPATH
echo "Adding the " $NEWPATH " directory to PATH."
PATH=$PATH:$NEWPATH
export PATH
echo "Your PATH env variable is now:"
echo $PATH
exit 0
