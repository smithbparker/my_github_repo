echo $$
B="This script is executed"
echo $B
